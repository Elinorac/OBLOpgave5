﻿using System;

namespace OPG5TCPServer
{
    class Program
    {
        static void Main(string[] args)
        {
            ServerWorker worker = new ServerWorker();
            worker.Start();
        }
    }
}
