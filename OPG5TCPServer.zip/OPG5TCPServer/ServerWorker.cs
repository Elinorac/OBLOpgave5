﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using OPG1Football;


namespace OPG5TCPServer
{
    class ServerWorker
    {
        private static List<FootballPlayer> _footballPlayers = new List<FootballPlayer>()
        {
            new FootballPlayer(1, "Lukas", 10000, 8),
            new FootballPlayer(2, "Kevin", 12000, 9),
            new FootballPlayer(3, "Mark", 11000, 10),
            new FootballPlayer(4, "Jacob", 14000, 11),
            new FootballPlayer(5, "Benjamin", 9500, 12),
            new FootballPlayer(6, "Morten", 14500, 13),
            new FootballPlayer(7, "Adam", 13500, 14),
            new FootballPlayer(8, "Daniel", 11500, 15)
        };

        public ServerWorker()
        {

        }

        public void Start()
        {
            TcpListener listener = new TcpListener(2121);
            listener.Start();

            while (true)
            {
                TcpClient socket = listener.AcceptTcpClient();
                Task.Run(
                    () =>
                    {
                        TcpClient tmpSocket = socket;
                        DoClient(tmpSocket);
                    }
                );
            }

        }

        public void DoClient(TcpClient socket)
        {
            using (StreamReader r = new StreamReader(socket.GetStream()))
            using (StreamWriter w = new StreamWriter(socket.GetStream()))
            {
                string str1 = r.ReadLine();
                string str2 = r.ReadLine();

                switch (str1)
                {
                    case "Hent alle":
                        string json = JsonSerializer.Serialize(_footballPlayers);
                        w.WriteLine(json);
                        w.Flush();
                        break;

                    case "Hent":
                        int id = Convert.ToInt32(str2);
                        FootballPlayer player = _footballPlayers.Find(P => P.Id == id);
                        string json2 = JsonSerializer.Serialize(player);
                        w.WriteLine(json2);
                        w.Flush();
                        break;
                    case "Gem":
                        FootballPlayer footballPlayer = JsonSerializer.Deserialize<FootballPlayer>(str2);
                        _footballPlayers.Add(footballPlayer);
                        break;

                }
            }
        }
    }
}
